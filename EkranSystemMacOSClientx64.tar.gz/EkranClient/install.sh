#!/bin/bash
#________________________ARGUMENTS________________________
EXIT_CODE_SUCEESS=0
EXIT_CODE_NO_ROOT=1
EXIT_CODE_INVALID_ARGS=2
EXIT_CODE_FAILED=3

INSTALL_MODE=0
UPDATE_MODE=1
INSTALL_INI_MODE=2

# By default
MODE=$UPDATE_MODE
HOST=""
PORT=9447 # Default port
TENANT_KEY="90807A10-DF80-45EA-A7DE-A550B55F548A" # Default tenant key

function usage {
    echo "Usage: $0 [ -h <host> [-p <port>] [-t <tenant_key>] | -u | -h ]"
    echo "-h <host>             Server host"
    echo "-p <port>             Server port connection (${PORT} by default)"
    echo "-t <tenant_key>       Server tenant key (Use default tenant by default)"
    echo "-u                    Update mode (this mode use by default)"
    echo "-h                    Help"
}

#--------------------------------- CONSTANTS ---------------------------------

PRODUCT_NAME="Ekran"
AGENT_NAME="${PRODUCT_NAME}AgentClient"
DAEMON_NAME="${PRODUCT_NAME}Agent"
APP_PATH="/Applications/${PRODUCT_NAME} System Client.app"
APP_EXECUTABLES_PATH="${APP_PATH}/Contents/MacOS"
AGENT_PATH="${APP_EXECUTABLES_PATH}/${AGENT_NAME}"
DAEMON_PATH="${APP_EXECUTABLES_PATH}/${DAEMON_NAME}"
APP_SYSTEM_CLIENT_PATH="${APP_EXECUTABLES_PATH}/${PRODUCT_NAME} System Client"
INI_FILE_NAME="settings.ini"
INI_FILE_PATH="$(dirname "$0")/${INI_FILE_NAME}"
TARGET_DIRECTORY_PATH=$(dirname "$0")

#--------------------------------- FUNCTIONS ---------------------------------
#
# Checks if a process is run
# Arguments:
# $1 - a path to process
# Return 0 - a process is run, otherwise - 1
#
function is_run_process {
    if [[ -n $(ps aux | grep -v grep | grep "$1") ]]; then
        echo 0
    else
        echo 1
    fi
}
#
# Checks if a ekran agent is run
# Return 0 - a app is run, otherwise - 1
#
function is_run_ekran {
    if [[ $(is_run_process "${DAEMON_NAME}") == 0 ]] && [[ $(is_run_process "${AGENT_NAME}") == 0 ]]; then
        echo 0
    else
        echo 1
    fi
}

PARSED_ARGS=0

if [[ $(is_run_ekran) != 0 ]] && [[ -f "${INI_FILE_PATH}" ]]; then
    MODE=$INSTALL_INI_MODE
fi

while getopts "h::p:t:u" arg; do
    PARSED_ARGS=1
    case ${arg} in
        h)
            if [[ -z "${OPTARG}" ]]; then
                # Help
                usage; exit $EXIT_CODE_SUCEESS
            else
                MODE=$INSTALL_MODE
                HOST="${OPTARG}"
            fi
        ;;

        p)
            if [[ $MODE != $INSTALL_MODE ]] && [[ $MODE != $INSTALL_INI_MODE ]]; then
                usage; exit $EXIT_CODE_INVALID_ARGS
            else
                PORT="${OPTARG}"
            fi
        ;;
        
        t)
            if [[ $MODE != $INSTALL_MODE ]] && [[ $MODE != $INSTALL_INI_MODE ]]; then
                usage; exit $EXIT_CODE_INVALID_ARGS
            else
                TENANT_KEY="${OPTARG}"
            fi
        ;;
        
        u)
            MODE=$UPDATE_MODE
        ;;

        *)
            usage; exit $EXIT_CODE_INVALID_ARGS
        ;;
    esac
done

if [[ "$#" > 1 ]] && [[ $PARSED_ARGS == 0 ]]; then
    usage; exit $EXIT_CODE_INVALID_ARGS
fi

if [[ "$#" == 0 ]] && [[ $PARSED_ARGS == 0 ]] && [[ $MODE != $INSTALL_INI_MODE ]] && [[ $MODE != $UPDATE_MODE ]]; then
    usage; exit $EXIT_CODE_INVALID_ARGS
fi

if [[ $MODE == "$UPDATE_MODE" ]] && [[ $(is_run_process "${DAEMON_NAME}") != 0 ]]; then
    echo "Failed to update, the app not run"; usage; exit $EXIT_CODE_INVALID_ARGS
fi

if [[ $EUID -ne 0 ]]; then
    echo "The $(basename "$0") must be run with sudo"; exit $EXIT_CODE_NO_ROOT
fi

#__________________________MAIN_____________________________

PKG_FILE_NAME=$(ls "${TARGET_DIRECTORY_PATH}" | grep .pkg)
if [[ -z "${PKG_FILE_NAME}" ]]; then
    echo "Failed to find pkg file in "${TARGET_DIRECTORY_PATH}""; exit $EXIT_CODE_FAILED
fi

PKG_FILE_PATH="${TARGET_DIRECTORY_PATH}/${PKG_FILE_NAME}"

installer -pkg "${PKG_FILE_PATH}" -target /; return_code=$?
if [[ $return_code != 0 ]]; then
    echo "Failed to run pkg file ${PKG_FILE_PATH}. Error code: "$return_code""; exit $EXIT_CODE_FAILED
fi

if [[ $MODE == "$UPDATE_MODE" ]]; then
    echo "Updating..."
    "${APP_SYSTEM_CLIENT_PATH}" -s -u; return_code=$?
elif [[ $MODE == "$INSTALL_MODE" ]]; then
    echo "Installation: Host - ${HOST}, Port - ${PORT}, Tenant key - ${TENANT_KEY}"
    "${APP_SYSTEM_CLIENT_PATH}" -s -h"${HOST}" -p"${PORT}" -t"${TENANT_KEY}"; return_code=$?
elif [[ $MODE == "$INSTALL_INI_MODE" ]]; then
     echo "Installation via *.ini file..."
     "${APP_SYSTEM_CLIENT_PATH}" -s -i -p"${PORT}" -t"${TENANT_KEY}"; return_code=$?
fi

if [[ $return_code != 0 ]]; then
    echo "Failed to run app ${APP_SYSTEM_CLIENT_PATH}. Error code: "$return_code""; exit $EXIT_CODE_FAILED
fi

exit $EXIT_CODE_SUCEESS
