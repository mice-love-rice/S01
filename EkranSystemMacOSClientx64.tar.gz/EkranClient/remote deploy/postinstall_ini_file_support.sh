#!/bin/bash
#
# Postinstall script for macOS remote deploy manager with *.ini file
#
# Run this script if you want to install clients using parameters from *.ini file
#
# Open the settings.ini file from the installation pack, copy all the contents and replace DATA here
SETTINGS_INI_FILE_DATA="DATA";

echo  "${SETTINGS_INI_FILE_DATA}" > /Applications/Ekran\ System\ Client.app/Contents/Library/settings.ini

/Applications/Ekran\ System\ Client.app/Contents/MacOS/Ekran\ System\ Client -s -i
