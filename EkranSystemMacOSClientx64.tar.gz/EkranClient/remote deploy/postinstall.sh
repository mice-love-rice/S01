#!/bin/bash
#
# Postinstall script for macOS remote deploy manager
#

# Replace the name or IP address(es) of the Ekran System Server(s) and the port used to connect to the Ekran System Server
# If you want to use several IP addreses, separate it by ";" without any space
SERVER="X.X.X.X"
PORT="9447"
# Replace the default tenant key to use a multi-tenant mode
TENANT_KEY="90807A10-DF80-45EA-A7DE-A550B55F548A"

/Applications/Ekran\ System\ Client.app/Contents/MacOS/Ekran\ System\ Client -s -h"${SERVER}" -p"${PORT}" -t"${TENANT_KEY}"
